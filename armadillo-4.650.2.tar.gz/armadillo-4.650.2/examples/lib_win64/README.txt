The lib and dll files in this folder are for 64 bit Windows 7.
They are compiled versions of standard BLAS and LAPACK libraries,
which are distributed under a BSD license.

The compilation was done by a third party.  USE AT YOUR OWN RISK.
The compiled versions of LAPACK and BLAS were obtained from:
  http://ylzhao.blogspot.com.au/2013/10/blas-lapack-precompiled-binaries-for.html

You can find the original sources for standard BLAS and LAPACK at:
  http://www.netlib.org/blas/
  http://www.netlib.org/lapack/
  
Faster and/or alternative implementations of BLAS and LAPACK are available:
  http://software.intel.com/en-us/intel-mkl/
  http://developer.amd.com/tools-and-sdks/cpu-development/amd-core-math-library-acml/
  http://xianyi.github.com/OpenBLAS/
  http://www.stanford.edu/~vkl/code/libs.html
  http://icl.cs.utk.edu/lapack-for-windows/lapack/
